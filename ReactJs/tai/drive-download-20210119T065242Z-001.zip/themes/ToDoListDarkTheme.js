export const ToDoListDarkTheme = {
    bgColor: '#343a40',
    color:'#fff',
    borderButton: '1px solid #fff',
    borderRadiusButton: 'none',
    hoverTextColor: '#343a40',
    hoverBgColor:'#fff',
    borderColor:'#343a40'
}